import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'myapp';
  private APIUrl = "http://localhost:5038/api/todoapp/";
  employeeList: EmployeeDto[]; 
  dto:EmployeeDto;

  constructor(private http: HttpClient) {
this.dto=new EmployeeDto();
this.employeeList=[];


  }
  Getnotes:any =[];

  ngOnInit() {
    this.resfreshNote();
  }

  resfreshNote() {
    this.http.get<EmployeeDto[]>(this.APIUrl + 'GetNode').subscribe(
      (response) => {
        this.employeeList = response;
        debugger
      },
      (Error) => {
        console.log(Error);
      }
    );
  }

  addNotes() {
    debugger
    if(this.dto.id==0)
    {
      const payload = {
        newnotes: this.dto.description
      }
      this.http.post(this.APIUrl + 'Addnotes', payload).subscribe(data => {
        alert(data);
        // this.Note = null
        this.dto=new EmployeeDto();
        this.resfreshNote();
      });
    }
    else
    {
      const payload = {
      id:this.dto.id,
      newDescription: this.dto.description
    }
    this.http.put(this.APIUrl + 'editNote', payload).subscribe(data => {
      alert(data);
      this.dto=new EmployeeDto();
      this.resfreshNote();
    });
    }
  }
  deleteNotes(id: any) {
    this.http.delete(this.APIUrl + 'deleteNodes?id=' + id).subscribe(data => {
      alert(data);
      this.resfreshNote();
    });
  }
  editNote(id:number,description:string)
  {
      this.dto.id=id;
      this.dto.description=description;
  }
}  
export class EmployeeDto
{
  id:number=0;
  description!:string;
} 
