const express = require("express");
// const mongoose = require("mongoose");
const cors = require("cors");
const { MongoClient } = require("mongodb");
const app = express();
// Enable CORS
app.use(cors());

// Enable parsing of JSON request bodies
app.use(express.json());
var database;
var dataTableName = "Test";
// const CONNECTION_STRING = "mongodb://User:User1234@cluster0-shard-00-00.yi9pi.mongodb.net:27017,cluster0-shard-00-01.yi9pi.mongodb.net:27017,cluster0-shard-00-02.yi9pi.mongodb.net:27017/Test?ssl=true&replicaSet=atlas-10ygg7-shard-0&authSource=admin&retryWrites=true&w=majority";

const CONNECTION_STRING = "mongodb+srv://User:User1324@cluster0.yi9pi.mongodb.net/Test?retryWrites=true&w=majority";
const PORT = 5038;

MongoClient.connect(CONNECTION_STRING, { useNewUrlParser: true, useUnifiedTopology: true })
    .then((client) => {
        database = client.db(dataTableName);
        console.log("MongoDB Connection Successful");

        // Start the server
        app.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
        });
    })
    .catch((error) => {
        console.error("MongoDB Connection Error:", error);
    });


//Data Acess
app.get('/api/todoapp/GetNode', (req, res) => {
    database.collection("todoappcollection").find({}).toArray((error, result) => {
        if (error) {
            return res.status(500).send("Error fetching data");
        }
        res.status(200).send(result);
    });
});

//input krna backend insert 
app.post('/api/todoapp/AddNotes', (req, res) => {
    debugger
    debugger
    console.log(req.body)
    console.log(req.body.newnotes)
    database.collection("todoappcollection").countDocuments({}, (error, numOfDocs) => {
        if (error) {
            return res.status(500).send("Error counting documents");
        }

        database.collection("todoappcollection").insertOne({
            id: (numOfDocs + 1).toString(),
            description: req.body.newnotes
        }, (err, result) => {
            if (err) {
                return res.status(500).send("Error adding note");
            }
            res.json("Added Successfully");
        });
    });
});


app.put('/api/todoapp/editNote', (req, res) => {
    console.log(req)
    const noteId = req.body.id; // The `id` of the note to edit
    const updatedDescription = req.body.newDescription; // New description

    console.log(req.body.id, req.body)
    if (!noteId || !updatedDescription) {
        return res.status(400).send("Missing required fields: id or newDescription");
    }

    database.collection("todoappcollection").updateOne(
        { id: noteId }, // Filter criteria to find the note
        { $set: { description: updatedDescription } }, // Update operation
        (err, result) => {
            if (err) {
                return res.status(500).send("Error updating note");
            }

            if (result.matchedCount === 0) {
                return res.status(404).send("Note not found");
            }

            res.json("Updated Successfully");
        }
    );
});


app.delete('/api/todoapp/deleteNodes', (req, res) => {
    database.collection("todoappcollection").deleteOne({
        id: req.query.id
    }, (err, result) => {
        if (err) {
            return res.status(500).send("Error deleting note");
        }
        res.json("Deleted Successfully");
    });
});

